from neo4j import GraphDatabase

uri = "bolt://localhost:7687"
user = "neo4j"
psw = "giuseppe"

driver = GraphDatabase.driver(uri, auth=(user, psw))
session = driver.session()


session.run("CREATE CONSTRAINT ON (a:USER) ASSERT a.cf is unique;")
session.run("CREATE CONSTRAINT ON (b:EVAL) assert b.id_eval is unique;")
session.run("CREATE CONSTRAINT ON (c:CLAIM) assert c.id_cla is unique;")
session.run("CREATE CONSTRAINT ON (d:LAWYER) assert d.id_law is unique;")
session.run("CREATE CONSTRAINT ON (e:COMPANY) assert e.id_company is unique;")
session.run("CREATE CONSTRAINT ON (f:TYPE) assert f.id_type is unique;")
session.run("CREATE CONSTRAINT ON (g:STATE) assert g.id_state is unique;")
session.run("CREATE CONSTRAINT ON (h:DATE) assert h.id_date is unique;")


#vengono creati i nodi###
session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv"  AS row
MERGE (a:USER  {cf: row.CF})
ON CREATE SET a.name = row.NAME, a.email= row.EMAIL, a.cell = row.CELL , a.address=row.ADDRESS
ON MATCH SET a.name =row.NAME,  a.email= row.EMAIL, a.cell = row.CELL , a.address=row.ADDRESS 

MERGE (b:EVAL {id_eval : row.EVALUATED})
MERGE (c:CLAIM {id_cla : row.CLAIM})
MERGE (d:LAWYER {id_law: row.LAWYER})
MERGE (e:COMPANY {id_company: row.COMPANY})
MERGE (f:TYPE {id_type :row.TYPE})
MERGE (g:STATE {id_state: row.STATE})
MERGE (h:DATE {id_date : row.DATE})
""")


#Vengono create le relazioni #
session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH (c:CLAIM {id_cla: row.CLAIM}), (f:TYPE {id_type: row.TYPE})
CREATE (c)-[:have_ONE]->(f)""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH (a:USER {cf: row.CF}), (c:CLAIM {id_cla: row.CLAIM}), (f:TYPE {id_type: row.TYPE})
CREATE (a)-[:is_RECALL]->(c)-[:have_ONE]->(f)
""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH  (d:LAWYER {id_law: row.LAWYER}), (c:CLAIM {id_cla: row.CLAIM}) 
CREATE (d)-[:is_INVOLVED_LAWYER]->(c)
""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH  (b:EVAL {id_eval: row.EVALUATED}), (c:CLAIM {id_cla: row.CLAIM})
CREATE (b)-[:is_INVOLVED_EVAL]->(c)
""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH  (d:LAWYER {id_law: row.LAWYER}), (e:COMPANY {id_company: row.COMPANY})
CREATE (d)-[:work_FOR_LAWYER]->(e)
""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH  (b:EVAL {id_eval: row.EVALUATED}), (e:COMPANY {id_company: row.COMPANY})
CREATE (b)-[:work_FOR_EVAL]->(e)
""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH (c:CLAIM {id_cla: row.CLAIM}), (g:STATE {id_state: row.STATE})
CREATE (c)-[:is_SITUATED]->(g)""")

session.run("""LOAD CSV WITH HEADERS FROM "file:///dataset10000.csv" AS row
MATCH (c:CLAIM {id_cla: row.CLAIM}), (h:DATE {id_date: row.DATE})
CREATE (c)-[:has_BEEN_DONE]->(h)""")



